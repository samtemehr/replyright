# ReplyRight Chrome Extension

> Write in any language. Send in perfect English.

## ساختار فایل‌ها

```
replyright/
├── manifest.json     ← قلب اکستنشن
├── content.js        ← تشخیص textarea و نمایش پنل
├── content.css       ← استایل دکمه و پنل
├── popup.html        ← UI تنظیمات
├── popup.js          ← منطق تنظیمات
├── background.js     ← Service Worker
└── icons/
    ├── icon16.png    ← باید خودت بسازی
    ├── icon48.png
    └── icon128.png
```

## نصب روی Chrome (بدون Web Store)

1. پوشه `replyright` را روی کامپیوترت ذخیره کن
2. Chrome را باز کن
3. برو به `chrome://extensions`
4. گوشه راست بالا **Developer mode** را روشن کن
5. کلیک کن **Load unpacked**
6. پوشه `replyright` را انتخاب کن
7. اکستنشن نصب شد!

## اضافه کردن آیکون

فعلاً یک فایل PNG ساده (هر اندازه‌ای) با نام‌های زیر بساز:
- icons/icon16.png
- icons/icon48.png  
- icons/icon128.png

یا از یک سایت مثل https://favicon.io یک آیکون بساز.

## گرفتن API Key

1. برو به https://console.anthropic.com
2. یک حساب رایگان بساز
3. از بخش API Keys یک کلید جدید بساز
4. کلید را در popup اکستنشن وارد کن

## تست اکستنشن

1. برو به Gmail یا LinkedIn
2. روی یک textarea کلیک کن
3. دکمه **ReplyRight** را ببین
4. کلیک کن و متنت را بنویس

## قدم‌های بعدی

- [ ] آیکون‌های واقعی بساز
- [ ] صفحه landing page بساز
- [ ] Stripe وصل کن ($9/month)
- [ ] در Chrome Web Store منتشر کن ($5 یک‌بار)
- [ ] در ProductHunt لانچ کن
