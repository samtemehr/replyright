// ReplyRight — popup.js (v9)

const WALLET_ADDRESS = "TRUktVfTYqvG5MggwSDrhdooH856veGbfL"; // آدرس TRC-20 خودت
const SUPPORT_EMAIL  = "samtemehr@gmail.com";
const PRO_PRICE_USD  = 9;

// ---- کلید مخفی برای تولید کد فعال‌سازی (فقط تو می‌دانی) ----
const SECRET_KEY = "rr2025secret#mehdi";

const i18n = {
  fa: {
    usage: "مصرف امروز", used: "پیام ارسال شده",
    upgradeTitle: "ارتقا به Pro",
    f1: "✓ پیام نامحدود روزانه", f2: "✓ همه لحن‌ها فعال", f3: "✓ اولویت در پشتیبانی",
    upgradeDesc: "فقط معادل $9 در ماه",
    upgradeBtn: "💳 خرید اشتراک Pro →",
    footer: "بدون نیاز به تنظیمات",
    activateBtn: "🔑 وارد کردن کد فعال‌سازی",
    activatePlaceholder: "کد فعال‌سازی را اینجا وارد کنید",
    activateSubmit: "فعال‌سازی",
    activateSuccess: "✅ Pro فعال شد!",
    activateError: "❌ کد نادرست است",
    // Payment view
    back: "بازگشت",
    payTitle: "خرید اشتراک Pro",
    paySub: "$9 در ماه — پیام نامحدود",
    cryptoName: "ارز دیجیتال",
    cryptoDesc: "USDT / TRX — شبکه TRC-20",
    cryptoBadge: "بین‌الملل",
    zarrinName: "کارت به کارت",
    zarrinDesc: "پرداخت ریالی — کارت بانکی",
    zarrinBadge: "ایران",
    // Crypto view
    cryptoTitle: "پرداخت با USDT یا TRX",
    cryptoSub: "مبلغ زیر را به آدرس کیف پول واریز کنید:",
    network: "شبکه",
    usdtAmount: "مبلغ USDT",
    trxAmount: "مبلغ TRX",
    walletAddr: "آدرس کیف پول",
    uidLabel: "🔑 کد کاربری شما (در ایمیل درج کنید)",
    uidHint: "روی کد کلیک کنید تا کپی شود",
    sendEmailCrypto: "ارسال ایمیل تأیید پرداخت",
    // Zarrin view
    zarrinTitle: "پرداخت ریالی —کارت به کارت",
    zarrinSub: "معادل ریالی $9 از طریق درگاههای بانکی:",
    amount: "مبلغ",
    cardNum: "شماره کارت",
    cardName: "به نام",
    bank: "بانک",
    receiptWarning: "⚠️ بعد از واریز، رسید بانکی را به ایمیل <strong>پیوست</strong> کنید",
    afterPayment: "— بعد از واریز —",
    sendEmailZarrin: "ارسال ایمیل تأیید پرداخت",
    // Activate view
    activateTitle: "🔑 فعال‌سازی Pro",
    activateSub: "کد فعال‌سازی که از پشتیبانی دریافت کردی را وارد کن:",
    calculating: "در حال محاسبه...",
    clickToCopy: "کلیک کنید",
    // Toast messages
    addressCopied: "آدرس کپی شد ✓",
    cardCopied: "شماره کارت کپی شد ✓",
    uidCopied: "کد کاربری کپی شد ✓",
    langActivated: "فارسی فعال شد ✓",
  },
  en: {
    usage: "Today's Usage", used: "Messages used",
    upgradeTitle: "Upgrade to Pro",
    f1: "✓ Unlimited daily messages", f2: "✓ All tones unlocked", f3: "✓ Priority support",
    upgradeDesc: "Only $9/month",
    upgradeBtn: "💳 Get Pro →",
    footer: "No setup required",
    activateBtn: "🔑 Enter Activation Code",
    activatePlaceholder: "Enter your activation code",
    activateSubmit: "Activate",
    activateSuccess: "✅ Pro activated!",
    activateError: "❌ Invalid code",
    // Payment view
    back: "Back",
    payTitle: "Buy Pro Subscription",
    paySub: "$9/month — Unlimited messages",
    cryptoName: "Cryptocurrency",
    cryptoDesc: "USDT / TRX — TRC-20 network",
    cryptoBadge: "International",
    zarrinName: "Rial Payment — Bank Card",
    zarrinBadge: "Iran",
    // Crypto view
    cryptoTitle: "Pay with USDT or TRX",
    cryptoSub: "Send the amount below to the wallet address:",
    network: "Network",
    usdtAmount: "USDT Amount",
    trxAmount: "TRX Amount",
    walletAddr: "Wallet Address",
    uidLabel: "🔑 Your User ID (include in email)",
    uidHint: "Click code to copy",
    sendEmailCrypto: "Send Payment Confirmation Email",
    // Zarrin view
    zarrinTitle: "Rial Payment — Zarinpal",
    zarrinSub: "Rial equivalent of $9 via Zarinpal gateway:",
    amount: "Amount",
    cardNum: "Card Number",
    cardName: "Cardholder",
    bank: "Bank",
    receiptWarning: "⚠️ After payment, <strong>attach</strong> the bank receipt to the email",
    afterPayment: "— After Payment —",
    sendEmailZarrin: "Send Payment Confirmation Email",
    // Activate view
    activateTitle: "🔑 Activate Pro",
    activateSub: "Enter the activation code you received from support:",
    calculating: "Calculating...",
    clickToCopy: "Click to copy",
    // Toast messages
    addressCopied: "Address copied ✓",
    cardCopied: "Card number copied ✓",
    uidCopied: "User ID copied ✓",
    langActivated: "English activated ✓",
  }
};

let currentLang = "fa";
let userUID = "";

document.addEventListener("DOMContentLoaded", async () => {
  const { lang, isPro, uid } = await chrome.storage.sync.get(["lang","isPro","uid"]);

  // UID یکتا برای هر کاربر
  if (uid) {
    userUID = uid;
  } else {
    userUID = generateUID();
    await chrome.storage.sync.set({ uid: userUID });
  }

  // Set wallet address
  const walletEl = document.getElementById("wallet-addr");
  if (walletEl) walletEl.textContent = WALLET_ADDRESS;

  currentLang = lang || "fa";
  applyLang(currentLang);
  await loadUsage(isPro);

  if (isPro) {
    document.getElementById("upgrade-section").style.display = "none";
  }

  // رویدادها
  document.getElementById("btn-fa").addEventListener("click", () => setLang("fa"));
  document.getElementById("btn-en").addEventListener("click", () => setLang("en"));
  document.getElementById("upgrade-btn").addEventListener("click", () => showView("payment-view"));
  document.getElementById("back-btn-pay").addEventListener("click", () => showView("main-view"));
  document.getElementById("back-btn-crypto").addEventListener("click", () => showView("payment-view"));
  document.getElementById("back-btn-zarrin").addEventListener("click", () => showView("payment-view"));

  // کپی‌ها
  document.getElementById("wallet-addr").addEventListener("click", () => {
    navigator.clipboard.writeText(WALLET_ADDRESS);
    showToast(i18n[currentLang].addressCopied);
  });
  document.getElementById("uid-display").addEventListener("click", () => {
    navigator.clipboard.writeText(userUID);
    showToast(i18n[currentLang].uidCopied);
  });
  document.getElementById("uid-display-2").addEventListener("click", () => {
    navigator.clipboard.writeText(userUID);
    showToast(i18n[currentLang].uidCopied);
  });

  // کپی شماره کارت
  const cardEl = document.getElementById("card-num");
  if (cardEl) {
    cardEl.addEventListener("click", () => {
      navigator.clipboard.writeText("5022291502796962");
      showToast(i18n[currentLang].cardCopied);
    });
  }

  // ایمیل خودکار کریپتو
  document.getElementById("send-email-crypto").addEventListener("click", () => sendEmail("crypto"));
  document.getElementById("send-email-zarrin").addEventListener("click", () => sendEmail("zarrin"));

  // کد فعال‌سازی
  document.getElementById("activate-btn").addEventListener("click", () => showView("activate-view"));
  document.getElementById("back-btn-activate").addEventListener("click", () => showView("main-view"));
  document.getElementById("activate-submit").addEventListener("click", activatePro);

  // لود قیمت TRX
  loadTRXPrice();
});

// ---- نمایش view ----
function showView(id) {
  ["main-view","payment-view","crypto-view","zarrin-view","activate-view"].forEach(v => {
    document.getElementById(v).style.display = "none";
  });
  document.getElementById(id).style.display = "block";

  // وقتی صفحه پرداخت باز می‌شود، بر اساس زبان نمایش بده
  if (id === "payment-view") {
    if (currentLang === "fa") {
      document.getElementById("pay-crypto").style.display = "none";
      document.getElementById("pay-zarrin").style.display = "flex";
    } else {
      document.getElementById("pay-crypto").style.display = "flex";
      document.getElementById("pay-zarrin").style.display = "none";
    }
    document.getElementById("pay-crypto").addEventListener("click", () => showView("crypto-view"));
    document.getElementById("pay-zarrin").addEventListener("click", () => showView("zarrin-view"));
  }

  // نمایش UID در صفحات پرداخت
  if (id === "crypto-view" || id === "zarrin-view") {
    document.getElementById("uid-display").textContent  = userUID;
    document.getElementById("uid-display-2").textContent = userUID;
  }
}

// ---- قیمت زنده TRX ----
async function loadTRXPrice() {
  try {
    const res = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=tron&vs_currencies=usd");
    const data = await res.json();
    const trxPrice = data?.tron?.usd;
    if (trxPrice) {
      const trxAmount = (PRO_PRICE_USD / trxPrice).toFixed(0);
      const el = document.getElementById("trx-amount");
      if (el) el.textContent = `${trxAmount} TRX`;
      const el2 = document.getElementById("trx-amount-2");
      if (el2) el2.textContent = `یا ${trxAmount} TRX`;
    }
  } catch {
    const el = document.getElementById("trx-amount");
    if (el) el.textContent = "~270 TRX";
  }
}

// ---- ایمیل خودکار ----
function sendEmail(method) {
  let subject, body;

  if (method === "crypto") {
    const trxEl = document.getElementById("trx-amount");
    const trxAmt = trxEl ? trxEl.textContent : "~270 TRX";
    subject = `ReplyRight Pro Payment – User ID: ${userUID} [${currentLang.toUpperCase()}]`;
    body = `Hello,

I have completed payment for ReplyRight Pro.

━━━━━━━━━━━━━━━━━━━━━━
  USER ID : ${userUID}
  LANGUAGE: ${currentLang === "fa" ? "Persian (Farsi)" : "English"}
  METHOD  : USDT / TRX (TRC-20)
  AMOUNT  : 9 USDT  or  ${trxAmt}
  WALLET  : TRUktVfTYqvG5MggwSDrhdooH856veGbfL
━━━━━━━━━━━━━━━━━━━━━━

Transaction Hash (TX ID):
[PASTE YOUR TRANSACTION HASH HERE]

⚠️ Please attach a screenshot of your transaction receipt.

Kindly activate my Pro account.
Thank you.`;
  } else {
    subject = `فعال‌سازی ReplyRight Pro – کد کاربری: ${userUID} [${currentLang.toUpperCase()}]`;
    body = `سلام،

پرداخت اشتراک ReplyRight Pro انجام شد.

━━━━━━━━━━━━━━━━━━━━━━
  کد کاربری : ${userUID}
  زبان      : ${currentLang === "fa" ? "فارسی" : "انگلیسی"}
  روش پرداخت: کارت به کارت
  شماره کارت: 5022-2915-0279-6962
  به نام    : مهدی کریم‌زاد شریفی
  بانک      : پاسارگاد
  مبلغ      : ~۵۴۰,۰۰۰ تومان
━━━━━━━━━━━━━━━━━━━━━━

شماره پیگیری / کد مرجع:
[شماره پیگیری بانکی را اینجا وارد کنید]

⚠️ لطفاً رسید بانکی را به این ایمیل پیوست کنید.

لطفاً اشتراک Pro من را فعال کنید.
با تشکر`;
  }

  const mailto = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  chrome.tabs.create({ url: mailto });
}

// ---- فعال‌سازی Pro با کد ----
async function activatePro() {
  const input = document.getElementById("activate-input").value.trim();
  if (!input) return;

  const expectedCode = await generateActivationCode(userUID);

  if (input.toUpperCase() === expectedCode.toUpperCase()) {
    await chrome.storage.sync.set({ isPro: true });
    document.getElementById("activate-result").textContent = i18n[currentLang].activateSuccess;
    document.getElementById("activate-result").style.color = "#40c057";
    setTimeout(() => {
      showView("main-view");
      document.getElementById("upgrade-section").style.display = "none";
      loadUsage(true);
    }, 1500);
  } else {
    document.getElementById("activate-result").textContent = i18n[currentLang].activateError;
    document.getElementById("activate-result").style.color = "#e94560";
  }
}

// ---- تولید کد فعال‌سازی یکتا برای هر کاربر ----
// تو با UID کاربر + این تابع، کد را تولید می‌کنی و برایش می‌فرستی
async function generateActivationCode(uid) {
  const data = new TextEncoder().encode(uid + SECRET_KEY);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray  = Array.from(new Uint8Array(hashBuffer));
  // فقط ۸ کاراکتر اول — ساده‌تر برای تایپ
  return hashArray.map(b => b.toString(16).padStart(2,"0")).join("").slice(0,8).toUpperCase();
}

// ---- UID یکتا ----
function generateUID() {
  return "RR-" + Date.now().toString(36).toUpperCase() + "-" + Math.random().toString(36).slice(2,6).toUpperCase();
}

// ---- زبان ----
function applyLang(lang) {
  currentLang = lang;
  const t = i18n[lang];
  document.body.style.direction = lang === "fa" ? "rtl" : "ltr";
  document.getElementById("lbl-usage").textContent          = t.usage;
  document.getElementById("lbl-used").textContent           = t.used;
  document.getElementById("lbl-upgrade-title").textContent  = t.upgradeTitle;
  document.getElementById("lbl-f1").textContent             = t.f1;
  document.getElementById("lbl-f2").textContent             = t.f2;
  document.getElementById("lbl-f3").textContent             = t.f3;
  document.getElementById("lbl-upgrade-desc").textContent   = t.upgradeDesc;
  document.getElementById("upgrade-btn").textContent        = t.upgradeBtn;
  document.getElementById("lbl-footer").textContent         = t.footer;
  document.getElementById("activate-btn").textContent       = t.activateBtn;
  document.getElementById("activate-input").placeholder     = t.activatePlaceholder;
  document.getElementById("activate-submit").textContent    = t.activateSubmit;
  document.getElementById("btn-fa").classList.toggle("active", lang === "fa");
  document.getElementById("btn-en").classList.toggle("active", lang === "en");

  // Payment view
  if (document.getElementById("lbl-back")) document.getElementById("lbl-back").textContent = t.back;
  if (document.getElementById("lbl-pay-title")) document.getElementById("lbl-pay-title").textContent = t.payTitle;
  if (document.getElementById("lbl-pay-sub")) document.getElementById("lbl-pay-sub").textContent = t.paySub;
  if (document.getElementById("lbl-crypto-name")) document.getElementById("lbl-crypto-name").textContent = t.cryptoName;
  if (document.getElementById("lbl-crypto-desc")) document.getElementById("lbl-crypto-desc").textContent = t.cryptoDesc;
  if (document.getElementById("lbl-crypto-badge")) document.getElementById("lbl-crypto-badge").textContent = t.cryptoBadge;
  if (document.getElementById("lbl-zarrin-name")) document.getElementById("lbl-zarrin-name").textContent = t.zarrinName;
  if (document.getElementById("lbl-zarrin-desc")) document.getElementById("lbl-zarrin-desc").textContent = t.zarrinDesc;
  if (document.getElementById("lbl-zarrin-badge")) document.getElementById("lbl-zarrin-badge").textContent = t.zarrinBadge;

  // Crypto view
  if (document.getElementById("lbl-back-crypto")) document.getElementById("lbl-back-crypto").textContent = t.back;
  if (document.getElementById("lbl-crypto-title")) document.getElementById("lbl-crypto-title").textContent = t.cryptoTitle;
  if (document.getElementById("lbl-crypto-sub")) document.getElementById("lbl-crypto-sub").textContent = t.cryptoSub;
  if (document.getElementById("lbl-network")) document.getElementById("lbl-network").textContent = t.network;
  if (document.getElementById("lbl-usdt-amount")) document.getElementById("lbl-usdt-amount").textContent = t.usdtAmount;
  if (document.getElementById("lbl-trx-amount")) document.getElementById("lbl-trx-amount").textContent = t.trxAmount;
  if (document.getElementById("lbl-wallet-addr")) document.getElementById("lbl-wallet-addr").textContent = t.walletAddr;
  if (document.getElementById("lbl-uid-label")) document.getElementById("lbl-uid-label").textContent = t.uidLabel;
  if (document.getElementById("lbl-uid-hint")) document.getElementById("lbl-uid-hint").textContent = t.uidHint;
  if (document.getElementById("lbl-send-email-crypto")) document.getElementById("lbl-send-email-crypto").textContent = t.sendEmailCrypto;

  // Zarrin view
  if (document.getElementById("lbl-back-zarrin")) document.getElementById("lbl-back-zarrin").textContent = t.back;
  if (document.getElementById("lbl-zarrin-title")) document.getElementById("lbl-zarrin-title").textContent = t.zarrinTitle;
  if (document.getElementById("lbl-zarrin-sub")) document.getElementById("lbl-zarrin-sub").textContent = t.zarrinSub;
  if (document.getElementById("lbl-amount")) document.getElementById("lbl-amount").textContent = t.amount;
  if (document.getElementById("lbl-card-num")) document.getElementById("lbl-card-num").textContent = t.cardNum;
  if (document.getElementById("lbl-card-name")) document.getElementById("lbl-card-name").textContent = t.cardName;
  if (document.getElementById("lbl-bank")) document.getElementById("lbl-bank").textContent = t.bank;
  if (document.getElementById("lbl-receipt-warning")) document.getElementById("lbl-receipt-warning").innerHTML = t.receiptWarning;
  if (document.getElementById("lbl-uid-label-2")) document.getElementById("lbl-uid-label-2").textContent = t.uidLabel;
  if (document.getElementById("lbl-uid-hint-2")) document.getElementById("lbl-uid-hint-2").textContent = t.uidHint;
  if (document.getElementById("lbl-after-payment")) document.getElementById("lbl-after-payment").textContent = t.afterPayment;
  if (document.getElementById("lbl-send-email-zarrin")) document.getElementById("lbl-send-email-zarrin").textContent = t.sendEmailZarrin;

  // Activate view
  if (document.getElementById("lbl-back-activate")) document.getElementById("lbl-back-activate").textContent = t.back;
  if (document.getElementById("lbl-activate-title")) document.getElementById("lbl-activate-title").textContent = t.activateTitle;
  if (document.getElementById("lbl-activate-sub")) document.getElementById("lbl-activate-sub").textContent = t.activateSub;

  // Dynamic elements
  if (document.getElementById("lbl-trx-calculating")) document.getElementById("lbl-trx-calculating").textContent = t.calculating;
  if (document.getElementById("lbl-calculating")) document.getElementById("lbl-calculating").textContent = t.calculating;
  if (document.getElementById("lbl-click-to-copy")) document.getElementById("lbl-click-to-copy").textContent = t.clickToCopy;
}

async function setLang(lang) {
  await chrome.storage.sync.set({ lang });
  applyLang(lang);
  showToast(i18n[lang].langActivated);
}

async function loadUsage(isPro) {
  if (isPro) {
    document.getElementById("usage-count").textContent = "∞";
    document.getElementById("usage-fill").style.width  = "0%";
    return;
  }
  const { usageDate, usageCount } = await chrome.storage.local.get(["usageDate","usageCount"]);
  const today = new Date().toDateString();
  const count = usageDate === today ? (usageCount || 0) : 0;
  document.getElementById("usage-count").textContent = `${count} / 5`;
  document.getElementById("usage-fill").style.width  = `${(count/5)*100}%`;
}

function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2200);
}
