// ReplyRight — background.js (v6)
// API key اینجا ذخیره است — کاربر نمی‌بیند

const GROQ_API_KEY = "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"; // <-- کلید خودت را اینجا بگذار

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    // زبان پیش‌فرض
    chrome.storage.sync.set({ lang: "fa" });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "GENERATE") {
    handleGenerate(message).then(sendResponse);
    return true;
  }
});

async function handleGenerate({ intent, tone, lang }) {
  try {
    const toneMap = {
      professional: "formal and professional",
      friendly:     "warm, friendly and approachable",
      assertive:    "confident and assertive",
      concise:      "very brief and to the point"
    };

    // همیشه خروجی به انگلیسی باشد، فارغ از زبان ورودی
    const langInstruction = "IMPORTANT: Write the response in English ONLY. Do NOT write in Persian, Arabic, Spanish, or any other language. The output must be 100% English, regardless of what language the input is in.";

    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${GROQ_API_KEY}`,
        "Content-Type":  "application/json"
      },
      body: JSON.stringify({
        model:       "llama-3.1-8b-instant",
        max_tokens:  400,
        temperature: 0.7,
        messages: [
          {
            role:    "system",
            content: `You are an expert writer. ${langInstruction} Write ONLY the final message. No preamble, no explanation.`
          },
          {
            role:    "user",
            content: `The user wants to say: "${intent}"\nTone: ${toneMap[tone] || "professional"}\n\nWrite the message:`
          }
        ]
      })
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      return { error: err.error?.message || `API error ${res.status}` };
    }

    const data = await res.json();
    const text = data.choices?.[0]?.message?.content;
    if (!text) return { error: "No response. Try again." };
    return { text: text.trim() };

  } catch (err) {
    return { error: err.message };
  }
}
