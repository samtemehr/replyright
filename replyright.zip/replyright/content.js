// ReplyRight — content.js (v10 — simplified & reliable)

let lastTarget = null;
let btnEl = null;

// ---- شروع ----
init();

function init() {
  // هر ۱.۵ ثانیه یک‌بار field فعال را چک کن
  setInterval(checkActiveField, 1500);
  // همچنین با focus هم چک کن
  document.addEventListener("focusin", onFocus, true);
}

function onFocus(e) {
  setTimeout(() => checkActiveField(), 100);
}

function checkActiveField() {
  const el = document.activeElement;
  if (!el) return;

  if (isValidField(el)) {
    if (el !== lastTarget) {
      lastTarget = el;
      showButton(el);
    } else if (btnEl) {
      // اگر همان فیلد است، موقعیت دکمه را آپدیت کن
      positionBtn(el);
    }
  }
}

// ---- آیا این field مناسب است؟ ----
function isValidField(el) {
  if (!el) return false;
  const tag = el.tagName.toLowerCase();

  // textarea همیشه مناسب است
  if (tag === "textarea") return true;

  // input elements that are not buttons, checkboxes, etc.
  if (tag === "input" && !["submit", "button", "checkbox", "radio", "hidden", "file", "image", "reset", "password"].includes(el.type)) {
    return true;
  }

  // contenteditable — بررسی بیشتر
  if (el.contentEditable === "true") {
    // فیلدهای To/Subject/Search را رد کن
    const aria = (el.getAttribute("aria-label") || "").toLowerCase();
    const bad = ["to", "cc", "bcc", "subject", "search", "find", "recipients"];
    if (bad.some(w => aria.includes(w))) return false;
    return true;
  }

  // اگر عنصر داخلی یک contenteditable است، والد را پیدا کن
  const parent = el.closest('[contenteditable="true"]');
  if (parent) {
    const aria = (parent.getAttribute("aria-label") || "").toLowerCase();
    const bad = ["to", "cc", "bcc", "subject", "search", "find", "recipients"];
    if (bad.some(w => aria.includes(w))) return false;
    return true;
  }

  return false;
}

// ---- نمایش دکمه ----
function showButton(target) {
  removeButton();

  btnEl = document.createElement("div");
  btnEl.id = "rr-floating-btn";
  btnEl.innerHTML = "✦ ReplyRight";
  btnEl.style.cssText = `
    position: fixed;
    z-index: 2147483647;
    background: #e94560;
    color: #fff;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 2px 10px rgba(233,69,96,0.4);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    user-select: none;
    transition: opacity 0.2s;
    white-space: nowrap;
  `;

  positionBtn(target);
  document.body.appendChild(btnEl);

  btnEl.addEventListener("mousedown", (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (document.getElementById("rr-panel")) {
      document.getElementById("rr-panel").remove();
    } else {
      openPanel(target);
    }
  });

  // اگر کاربر جای دیگر کلیک کرد دکمه را پنهان کن
  document.addEventListener("mousedown", function hide(e) {
    if (btnEl && !btnEl.contains(e.target) && !e.target.closest("#rr-panel")) {
      removeButton();
      document.removeEventListener("mousedown", hide);
    }
  });
}

function positionBtn(target) {
  if (!btnEl) return;
  const rect = target.getBoundingClientRect();
  // گوشه راست-پایین بیرون textarea
  const btnW = 110, btnH = 28;
  let top  = rect.bottom + 8;
  let left = rect.right  - btnW - 8;

  // داخل viewport بماند
  if (top + btnH > window.innerHeight - 4) top = rect.top - btnH - 8;
  if (left < 4) left = 4;
  if (left + btnW > window.innerWidth - 4) left = window.innerWidth - btnW - 4;

  btnEl.style.top  = top  + "px";
  btnEl.style.left = left + "px";
}

function removeButton() {
  const old = document.getElementById("rr-floating-btn");
  if (old) old.remove();
  btnEl = null;
}

// ---- پنل اصلی ----
async function openPanel(target) {
  const { lang } = await chrome.storage.sync.get("lang");
  const isFA = (lang || "fa") === "fa";

  const t = {
    intentLabel:  isFA ? "چه می‌خواهی بگویی؟"      : "What do you want to say?",
    placeholder:  isFA ? "مثلاً: می‌خواهم بگویم که علاقه‌مند به همکاری هستم" : "e.g. I want to say I'm interested in working together",
    toneLabel:    isFA ? "لحن"                       : "Tone",
    generate:     isFA ? "✦ تولید متن"              : "✦ Generate",
    generating:   isFA ? "در حال تولید..."           : "Generating...",
    result:       isFA ? "نتیجه"                     : "Result",
    copy:         isFA ? "کپی"                       : "Copy",
    copied:       isFA ? "کپی شد!"                   : "Copied!",
    insert:       isFA ? "← درج در متن"             : "← Insert",
    noIntent:     isFA ? "لطفاً بنویس چه می‌خواهی بگویی" : "Please describe what you want to say",
    proOnly:      isFA ? "این لحن فقط در Pro موجود است" : "This tone is Pro only",
    freeLeft:     (n) => isFA ? `${n} پیام رایگان امروز` : `${n} free messages today`,
    tones: isFA
      ? { professional: "رسمی", friendly: "دوستانه", assertive: "قاطعانه 🔒" }
      : { professional: "Professional", friendly: "Friendly", assertive: "Assertive 🔒" }
  };

  const panel = document.createElement("div");
  panel.id = "rr-panel";
  panel.style.cssText = `
    position: fixed;
    z-index: 2147483646;
    width: 300px;
    background: #1a1a2e;
    border: 1px solid #2e2e4e;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.5);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Tahoma, sans-serif;
    color: #e8e8f0;
    direction: ${isFA ? "rtl" : "ltr"};
    overflow: hidden;
  `;

  panel.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 13px;background:#12122a;border-bottom:1px solid #2e2e4e">
      <span style="font-size:13px;font-weight:700;color:#fff">✦ ReplyRight</span>
      <button id="rr-close" style="background:none;border:none;color:#6e6e8a;cursor:pointer;font-size:14px;padding:0 4px;line-height:1">✕</button>
    </div>
    <div id="rr-usage-bar" style="padding:6px 13px;border-bottom:1px solid #2e2e4e"></div>
    <div style="padding:10px 13px 0">
      <div style="font-size:11px;color:#6e6e8a;margin-bottom:5px;text-transform:uppercase;letter-spacing:.04em">${t.intentLabel}</div>
      <textarea id="rr-intent" placeholder="${t.placeholder}" rows="3" style="width:100%;background:#12122a;border:1px solid #2e2e4e;border-radius:8px;color:#e8e8f0;font-size:13px;padding:8px 10px;outline:none;resize:none;box-sizing:border-box;font-family:inherit;direction:${isFA?"rtl":"ltr"}"></textarea>
    </div>
    <div style="padding:8px 13px 0">
      <div style="font-size:11px;color:#6e6e8a;margin-bottom:6px;text-transform:uppercase;letter-spacing:.04em">${t.toneLabel}</div>
      <div style="display:flex;gap:5px;flex-wrap:wrap">
        <button class="rr-tone active" data-tone="professional" style="padding:4px 10px;background:#e94560;border:1px solid #e94560;border-radius:14px;color:#fff;font-size:11px;font-family:inherit;cursor:pointer">${t.tones.professional}</button>
        <button class="rr-tone" data-tone="friendly" style="padding:4px 10px;background:#12122a;border:1px solid #2e2e4e;border-radius:14px;color:#8888aa;font-size:11px;font-family:inherit;cursor:pointer">${t.tones.friendly}</button>
        <button class="rr-tone rr-pro" data-tone="assertive" style="padding:4px 10px;background:#12122a;border:1px solid #2e2e4e;border-radius:14px;color:#5e5e7a;font-size:11px;font-family:inherit;cursor:pointer;opacity:.5">${t.tones.assertive}</button>
      </div>
    </div>
    <div style="padding:10px 13px">
      <button id="rr-gen" style="width:100%;padding:9px;background:#e94560;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:600;font-family:inherit;cursor:pointer">${t.generate}</button>
    </div>
    <div id="rr-result-wrap" style="display:none;margin:0 13px 10px;border:1px solid #2e2e4e;border-radius:8px;overflow:hidden">
      <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 10px;background:#12122a;border-bottom:1px solid #2e2e4e">
        <span style="font-size:10px;color:#6e6e8a;text-transform:uppercase;letter-spacing:.04em">${t.result}</span>
        <button id="rr-copy" style="background:none;border:1px solid #2e2e4e;color:#8888aa;font-size:11px;padding:2px 8px;border-radius:4px;cursor:pointer;font-family:inherit">${t.copy}</button>
      </div>
      <div id="rr-result-text" style="padding:10px;font-size:13px;color:#c8d3f5;line-height:1.6;white-space:pre-wrap;max-height:140px;overflow-y:auto;direction:ltr;text-align:left"></div>
      <button id="rr-insert" style="display:block;width:100%;padding:7px;background:#12122a;border:none;border-top:1px solid #2e2e4e;color:#8888aa;font-size:12px;font-family:inherit;cursor:pointer">${t.insert}</button>
    </div>
    <div style="display:flex;justify-content:space-between;padding:7px 13px;border-top:1px solid #2e2e4e;background:#12122a">
      <span id="rr-free-note" style="font-size:11px;color:#4e4e6a"></span>
      <span style="font-size:11px;color:#e94560;cursor:pointer">Pro →</span>
    </div>
  `;

  document.body.appendChild(panel);
  positionPanel(panel, target);
  setTimeout(() => document.getElementById("rr-intent")?.focus(), 60);

  // usage bar
  updateUsage(t);

  // بستن
  document.getElementById("rr-close").onclick = () => { panel.remove(); removeButton(); };

  // چک کردن وضعیت Pro برای فعال کردن Assertive
  const { isPro } = await chrome.storage.sync.get("isPro");
  if (isPro) {
    const assertiveBtn = panel.querySelector(".rr-tone[data-tone='assertive']");
    if (assertiveBtn) {
      assertiveBtn.classList.remove("rr-pro");
      assertiveBtn.style.opacity = "1";
      assertiveBtn.style.color = "#8888aa";
      assertiveBtn.textContent = isFA ? "قاطعانه" : "Assertive";
    }
  }

  // لحن
  let tone = "professional";
  panel.querySelectorAll(".rr-tone").forEach(btn => {
    btn.addEventListener("click", e => {
      e.preventDefault();
      if (btn.classList.contains("rr-pro")) { alert(t.proOnly); return; }
      panel.querySelectorAll(".rr-tone").forEach(b => {
        b.style.background = "#12122a"; b.style.borderColor = "#2e2e4e"; b.style.color = "#8888aa";
      });
      btn.style.background = "#e94560"; btn.style.borderColor = "#e94560"; btn.style.color = "#fff";
      tone = btn.dataset.tone;
    });
  });

  // Generate
  document.getElementById("rr-gen").onclick = async e => {
    e.preventDefault();
    const intent = document.getElementById("rr-intent").value.trim();
    if (!intent) { alert(t.noIntent); return; }
    const canUse = await checkUsage();
    if (!canUse) { showResult("You've used all 5 free messages today. Upgrade to Pro!"); return; }
    const btn = document.getElementById("rr-gen");
    btn.textContent = t.generating; btn.disabled = true;
    try {
      const resp = await chrome.runtime.sendMessage({ type: "GENERATE", intent, tone, lang: "en" });
      if (resp.error) showResult("❌ " + resp.error);
      else { showResult(resp.text); await incUsage(); updateUsage(t); }
    } catch(err) { showResult("❌ " + err.message); }
    finally { btn.textContent = t.generate; btn.disabled = false; }
  };

  // Copy
  document.getElementById("rr-copy").onclick = e => {
    e.preventDefault();
    navigator.clipboard.writeText(document.getElementById("rr-result-text").innerText);
    document.getElementById("rr-copy").textContent = t.copied;
    setTimeout(() => document.getElementById("rr-copy").textContent = t.copy, 2000);
  };

  // Insert
  document.getElementById("rr-insert").onclick = e => {
    e.preventDefault();
    insertText(target, document.getElementById("rr-result-text").innerText);
    panel.remove(); removeButton();
  };

  // کلیک بیرون
  setTimeout(() => {
    document.addEventListener("mousedown", function outside(e) {
      if (!panel.contains(e.target) && e.target.id !== "rr-floating-btn") {
        panel.remove();
        document.removeEventListener("mousedown", outside);
      }
    });
  }, 200);
}

function showResult(text) {
  document.getElementById("rr-result-text").innerText = text;
  document.getElementById("rr-result-wrap").style.display = "block";
}

function positionPanel(panel, target) {
  const pW = 300, pH = 420;
  const vW = window.innerWidth, vH = window.innerHeight;
  const rect = target.getBoundingClientRect();

  let top  = rect.bottom + 8;
  let left = rect.left;

  if (top + pH > vH - 10) top = Math.max(10, rect.top - pH - 8);
  if (left + pW > vW - 10) left = vW - pW - 10;
  if (left < 10) left = 10;

  panel.style.top  = top  + "px";
  panel.style.left = left + "px";
}

function insertText(target, text) {
  target.focus();
  if (target.tagName.toLowerCase() === "textarea") {
    const s = target.selectionStart || 0;
    const e = target.selectionEnd   || 0;
    target.value = target.value.substring(0,s) + text + target.value.substring(e);
    target.selectionStart = target.selectionEnd = s + text.length;
  } else if (target.contentEditable === "true") {
    const sel = window.getSelection();
    if (sel?.rangeCount) {
      const r = sel.getRangeAt(0);
      r.selectNodeContents(target);
      r.deleteContents();
      r.insertNode(document.createTextNode(text));
      r.collapse(false);
    } else { target.innerText = text; }
  }
  target.dispatchEvent(new Event("input",  { bubbles: true }));
  target.dispatchEvent(new Event("change", { bubbles: true }));
}

async function checkUsage() {
  const { isPro } = await chrome.storage.sync.get("isPro");
  if (isPro) return true;
  const { usageDate, usageCount } = await chrome.storage.local.get(["usageDate","usageCount"]);
  const today = new Date().toDateString();
  if (usageDate !== today) return true;
  return (usageCount || 0) < 5;
}

async function incUsage() {
  const { isPro } = await chrome.storage.sync.get("isPro");
  if (isPro) return;
  const { usageDate, usageCount } = await chrome.storage.local.get(["usageDate","usageCount"]);
  const today = new Date().toDateString();
  if (usageDate !== today) await chrome.storage.local.set({ usageDate: today, usageCount: 1 });
  else await chrome.storage.local.set({ usageCount: (usageCount||0)+1 });
}

async function updateUsage(t) {
  const bar = document.getElementById("rr-usage-bar");
  const note = document.getElementById("rr-free-note");
  if (!bar) return;
  const { isPro } = await chrome.storage.sync.get("isPro");
  if (isPro) { bar.style.display="none"; if(note) note.textContent="Pro ✦"; return; }
  const { usageDate, usageCount } = await chrome.storage.local.get(["usageDate","usageCount"]);
  const today = new Date().toDateString();
  const count = usageDate === today ? (usageCount||0) : 0;
  const rem = 5 - count;
  bar.innerHTML = `<div style="font-size:11px;color:#6e6e8a;margin-bottom:3px">${t.freeLeft(rem)}</div>
    <div style="height:3px;background:#2e2e4e;border-radius:2px;overflow:hidden">
      <div style="height:100%;width:${(count/5)*100}%;background:#e94560;border-radius:2px"></div>
    </div>`;
  if (note) note.textContent = t.freeLeft(rem);
}
